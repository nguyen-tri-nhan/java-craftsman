package ui;

import java.util.ArrayList;
import util.MyToys;

/**
 *
 * @author giao-lang | fb/giao.lang.bis
 * version 20.1106
 */

//class tạo cái menu in ra các lựa chọn món (chức năng) cho người dùng
//và mời gọi nhập các lựa chọn theo số lượng món đã định trước.
//dùng class này phối hợp với main() để điều hướng người sử dụng
//tương tác với app.
public class Menu {
    
    private String menuTitle;
    private ArrayList<String> optionList = new ArrayList();
    //lưu danh sách các lựa chọn/món ăn, chức năng
    
    //ví dụ: Mỗi dòng dưới đây là 1 món ăn, một chức năng
    //1. Thêm mới
    //2. Tìm
    //3. Sửa
    //4. Xóa
    //5. In danh sách (sắp xếp theo...)
    //6. In danh sách (sắp xếp theo...)
    //7. Thoát

    //khởi tạo tên của app., tên của menu
    public Menu(String menuTitle) {
        this.menuTitle = menuTitle;
    }
        
    //thêm một món vào thực đơn-danh sách
    //muốn có bao nhiêu món, bao nhiêu chức năng, gọi hàm này bấy nhiêu lần
    public void addNewOption(String newOption) {
        //TODO: cần kiểm tra coi option đưa vào có trùng với option
        //sẵn có hay ko?
        //nếu ko trùng, add vào danh sách lựa chọn
        
        optionList.add(newOption);        
    }
    
    //in ra danh sách các lựa chọn để người dùng chọn tính năng cần
    //dùng, món cần dùng
    public void printMenu() {
        
        if (optionList.isEmpty()) {
            System.out.println("There is no item in the menu");
            return;
        }
        System.out.println("\n------------------------------------");
        System.out.println("Welcome to " + menuTitle);
        for (String x : optionList)
            System.out.println(x);  
    }
    
    //có menu thì mới có lựa chọn
    //hàm trả về số thứ tự món mà người dùng đã nhập chọn
    //ứng với chức năng mà người dùng muốn app thực thi
    public int getChoice() {
        
        int maxOption = optionList.size();
        //lựa chọn lớn nhất là số thứ tự ứng với số món đang có        
        String inputMsg = "Choose [1.." + maxOption + "]: ";
        String errorMsg = "You are required to choose the option 1.." + maxOption; 
        return MyToys.getAnInteger(1, maxOption, inputMsg, errorMsg);
        
        //in ra câu nhập: Choose[1..8]: , giả sử có 8 mục chọn trong menu
        //và mời gõ/nhập số từ 1..8, đã chặn bắt nhập cà chớn dùng MyToys
    }
}
