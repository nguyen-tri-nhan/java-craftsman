package data;

/**
 *
 * @author giao-lang | fb/giao.lang.bis version 20.1106
 */

//class chính lưu hồ sơ của từng sinh viên
public class Student implements Comparable<Student> {

    private String id;   //mã số sv, theo định dạng, cấm trùng khi nhập từng hồ sơ
    private String name;
    private int yob;     //year of birth, năm sinh, để đơn giản xử lí, không lưu ngày
    private double gpa;  //grade point average, điểm trung bình

    public Student(String id, String name, int yob, double gpa) {
        this.id = id;
        this.name = name;
        this.yob = yob;
        this.gpa = gpa;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getYob() {
        return yob;
    }

    public void setYob(int yob) {
        this.yob = yob;
    }

    public double getGpa() {
        return gpa;
    }

    public void setGpa(double gpa) {
        this.gpa = gpa;
    }

    //hàm trả về chuỗi soái ca-gióng lề-tabular-Excel
    //Ví dụ: |SE123456|An Nguyễn Văn                 |2002|9.2|
    //Ví dụ: |SE123457|Bình Võ Thành Thanh           |2001|7.7|
    @Override
    public String toString() {
        return String.format("|%8s|%-30s|%4d|%4.1f|", id, name, yob, gpa);
    }

    //hàm in ra hồ sơ sinh viên kiểu chuỗi soái ca-gióng lề-tabular-Excel
    //Ví dụ: |SE123456|An Nguyễn Văn                 |2002|9.2|
    //Ví dụ: |SE123457|Bình Võ Thành Thanh           |2001|7.7|
    public void showProfile() {

        String record;
        record = String.format("|%8s|%-30s|%4d|%4.1f|", id, name, yob, gpa);
        System.out.println(record);
    }
    
    //mình [this] hay đi ghen tị GATO với thằng bạn [that] về việc đứng sau hay đứng
    //trước nó về mã số sinh viên
    @Override
    public int compareTo(Student that) {
        return this.id.compareToIgnoreCase(that.id);
    }   
    //so sánh tăng dần: [this] so với [that]
    //so sánh giảm dần: [that] so với [this]
}
