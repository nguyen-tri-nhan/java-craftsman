package data;

import java.util.*;
import util.MyToys;

/**
 *
 * @author giao-lang | fb/giao.lang.bis version 20.1106
 */

//1. tủ đựng hồ sơ các sinh viên, nên cần một mảng Student[] hoặc
//một ArrayList<Student> hoặc List<Student> để lưu trữ 
//2. cái tủ phải biết mở rộng cánh cửa đón nhận các hành động
//thêmHồSơ() xóaHồSơ() sửaHồSơ() tìmHồSơ() inDanhSách() liên quan đến
//các hồ sơ sinh viên mà nó chứa trong
public class Cabinet {  
    
    //dùng ArrayList, là 1 biến thể của mảng, để lưu danh sách sinh viên
    //phiên bản nâng cao xài Map, coming soon...
    private ArrayList<Student> studentList = new ArrayList();
    
    private Scanner sc = new Scanner(System.in);  
    //bàn phím xài chung cho các hàm ở phía dưới
   
    //-----------------------------------------------------
    //CÁC HÀNH ĐỘNG LIÊN QUAN ĐẾN TỦ HỒ SƠ
    //-----------------------------------------------------

    //1. THÊM MỚI HỒ SƠ SV .......... GỌI TỪ MAIN() 
    public void addANewStudent() {        
        
        //ta sẽ nhập từng miếng thông tin của SV ở đây qua lệnh Scanner
        String id, name;
        int yob;
        double gpa;
        int pos;  //lưu vị trí tìm thấy id 
        
        //chửi khi nhập sai định dạng id, hay nhập trùng id 
        do {
            //mã số SV là SEXXXXXX, SE kèm 6 con số            
            id = MyToys.getStringByPattern("Input student id (SEXXXXXX): ", 
                    "The format of id is SEXXXXXX (X stands for a digit)", "^[S|s][E|e]\\d{6}$");
            pos = searchStudentPositionById(id);
            if (pos >= 0)
                System.out.println("The student id already exists. Input another one!");
        } while (pos != -1);
         
        name = MyToys.getStringByFree("Input student name: ", "The student name is required!").toUpperCase();
        yob = MyToys.getAnInteger(1990, 2002, "Input student yob (1990..2002): ", "Yob must be in 1990..2002!");
        gpa = MyToys.getADouble(0.0, 10.0, "Input student gpa (0..10): ", "GPA must be in 0..10!");
        studentList.add(new Student(id, name, yob, gpa));
        System.out.println("A student profile is added successfully");
    }
    
    //2. TÌM HỒ SƠ SV .......... GỌI TỪ MAIN()      
    public void searchAStudentById() {
        
        //cần nhập id của sinh viên muốn tìm và gọi hàm helper để tìm giúp
        String id;
        Student x;  //con trỏ trỏ đến SV tìm thấy
        id = MyToys.getStringByFree("Input student id: ", "Student id is required!");
        x = searchStudentObjectById(id);
        System.out.println("------------------------------------");
        
        if (x == null)
            System.out.println("Student not found!!!");
        else {
            System.out.println("Here is the student that you want to search");
            x.showProfile();
        }     
    }
    
    //3. CẬP NHẬT THÔNG TIN SINH VIÊN .......... GỌI TỪ MAIN()    
    public void updateAStudent() {
        
        String id;
        String newName;  //nhập tên mới thay cho tên cũ
        Student x;  //con trỏ trỏ đến SV tìm thấy
        id = MyToys.getStringByFree("Input student id: ", "Student id is required!");
        x = searchStudentObjectById(id);
        System.out.println("------------------------------------");
        if (x == null)
            System.out.println("Student not found!!!");
        else {
            System.out.println("Here is the Student info before updating");
            x.showProfile();
            System.out.println("You are required to input a new student name");
            newName = MyToys.getStringByFree("Input a new student name: ", "Name is required!").toUpperCase();
            x.setName(newName);
            
            //TODO: thêm dàn sub menu cho lựa chọn update các thông tin của sinh viên
            //ta gọi lệnh Menu updatedMenu = new Menu();
            //và add các sub menu về lựa chọn update info gì của sv? name, yob, gpa
            //lưu ý: ko cho update id, vì id là key, ko cho sửa
            System.out.println("The student info is updated successfully as below!");
            x.showProfile();
        }     
    }
    
    //4. XÓA STUDENT .......... GỌI TỪ MAIN()
    public void removeAStudent() {
        
        String id;
        int pos; //vị trí tìm thấy sv
        id = MyToys.getStringByFree("Input student id: ", "Student id is required!");
        pos = searchStudentPositionById(id);
        System.out.println("------------------------------------");
        if (pos == -1)
            System.out.println("Student not found!!!");
        else {            
            //TODO: hỏi thêm Are you sure????
            //hoặc in ra info trước khi xóa để kiểm tra
            studentList.remove(pos);
            System.out.println("The selected student is removed successfully!");
        }     
    }
    
    //5. IN DANH SÁCH SINH VIÊN .......... GỌI TỪ MAIN()
    //in danh sách sv tăng dần theo ID
    //mặc định sv đc sort trên ID tăng dần, dùng cơ chế Comparable
    //mỗi sinh viên hay GATO với cùng đồng loại
    public void printStudentListAscendingByID() {
       
        if (studentList.isEmpty()) {
            System.out.println("Sorry, the cabinet is empty. Nothing to print. You must add a student before using this feature!");
            return;
        }
        
        Collections.sort(studentList);
        System.out.println("------------------------------------");
        System.out.println("Here is the student list ascending by id");
        String header = String.format("|%-8s|%-30s|%4s|%4s|", "ID", "Name", "YOB", "GPA");
        System.out.println(header);
        for (Student x : studentList) {
            x.showProfile();
        }
    }
     
    //6. IN DANH SÁCH SINH VIÊN .......... GỌI TỪ MAIN()
    //in danh sách sv giảm dần theo điểm trung bình
    //dùng cơ chế Comparator, Anonymous class, nâng cao sẽ dùng biểu thức Lambda
    //ta sẽ mượn, mua 1 cái cân 2 đĩa để cân 2 SV bất kì
    public void printStudentListDescendingByGpa() {
        if (studentList.isEmpty()) {
            System.out.println("Sorry, the cabinet is empty. Nothing to print. You must add a student before using this feature!");
            return;
        }
        
        //cái cân có 2 đĩa, chuyên đi cân 2 sv bất kì
        Comparator gpaBalance = new Comparator<Student>() {
            @Override
            public int compare(Student s1, Student s2) {
                return Double.compare(s2.getGpa(), s1.getGpa());
            }
        };                      
        //so sánh tăng dần: [s1] so với [s2]
        //so sánh giảm dần: [s2] so với [s1]
        
        Collections.sort(studentList, gpaBalance);
        System.out.println("------------------------------------");
        System.out.println("Here is the student list descending by gpa");
        String header = String.format("|%-8s|%-30s|%4s|%4s|", "ID", "Name", "YOB", "GPA");
        System.out.println(header);
        for (int i = 0; i < studentList.size(); i++)
            studentList.get(i).showProfile();
    }
    
    //hàm Helper/hàm phụ trợ ....................................
    //hàm này sẽ trả về vị trí tìm thấy sinh viên trong danh sách 
    //quy ước trả về: -1 hok tìm thấy 
    //        trả về: >=0 vị trí tìm thấy trong danh sách 
    public int searchStudentPositionById(String studentId) {
        
        //tìm kiếm: thuật toán trâu bò, rà, quét hết mảng/danh sách 
        //so khớp id của Student thứ i trong mảng/danh sách coi có bằng id đưa vào hem 
        int pos; 
        if (studentList.isEmpty()) //ko có SV nào trong danh sách, kết thúc cuộc chơi ngay
            return -1; 
        
        //quét hết list, coi có trùng id nào ko, có thì trả về vị trí
        for (int i = 0; i < studentList.size(); i++) 
            if (studentList.get(i).getId().equalsIgnoreCase(studentId))
                return i;            
        
        //đi hết cả for mà hok thấy, thì return -1, not found 
        return -1;            
    }
    
    //vi diệu, return an object
    //nếu tìm thấy, ta return con trỏ trỏ đến Student tìm thấy
    //tức là có 2 biến cùng trỏ vào vùng new Student() trước đó - hai chàng trỏ 1 nàng 
    public Student searchStudentObjectById(String studentId) {
        
        if (studentList.isEmpty())  //ko có sv nào, thì return null
            return null;        
        
        for (int i = 0; i < studentList.size(); i++)
            if (studentList.get(i).getId().equalsIgnoreCase(studentId))
                return studentList.get(i);
        
        //̣đi hết cả for mà hok thấy ai trùng id, đích thị là return null
        return null;
    }
    
}
