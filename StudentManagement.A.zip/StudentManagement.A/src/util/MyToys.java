package util;

import java.util.Scanner;

/**
 *
 * @author giao-lang | fb/giao.lang.bis
 * version 20.1106
 */

//class chứa các hàm đồ chơi, dùng cho việc nhập xuất dữ liệu
public class MyToys {

    private static Scanner sc = new Scanner(System.in);
    //xài chung bàn phím cho các hàm ở dưới cho tiết kiệm RAM

    //hàm nhập vào số nguyên đích thực
    //- mọi sự nhập cà chớn bị chửi, ví dụ nhập chuỗi thay vì nhập số
    //- chống trôi lệnh, tức là ko để lại rác Enter hay kí tự nào đó
    //  trong buffer cho thằng sau hốt
    //- có câu thông báo động, tùy ngữ cảnh 
    public static int getAnInteger(String inputMsg, String errorMsg) {
        int n;
        
        while (true) {
            try {
                System.out.print(inputMsg);
                n = Integer.parseInt(sc.nextLine()); //sống ko để lại rác
                return n;
            } catch (Exception e) {
                System.out.println(errorMsg);
            }
        }
    }

    //hàm nhập vào số nguyên đích thực trong khoảng cho trước
    //- mọi sự nhập cà chớn bị chửi, ví dụ nhập chuỗi thay vì nhập số
    //- chống trôi lệnh, tức là ko để lại rác Enter hay kí tự nào đó
    //  trong buffer cho thằng sau hốt 
    //- ép nhập số nguyên trong 1 range/khoảng cho trước
    //- có câu thông báo động, tùy ngữ cảnh 
    public static int getAnInteger(int lowerBound, int upperBound, String inputMsg, String errorMsg) {
        int n, tmp;
        
        //nếu đầu vào lower > upper thì hoán đổi cho thuận chiều
        //rằng nhập số trong khoảng từ lower -> đến upper
        //rằng nhập số trong khoảng từ bé -> đến lớn
        if (lowerBound > upperBound) {
            tmp = lowerBound;
            lowerBound = upperBound;
            upperBound = tmp;
        }
        
        while (true) {
            try {
                System.out.print(inputMsg);
                n = Integer.parseInt(sc.nextLine()); //sống ko để lại rác
                if (n < lowerBound || n > upperBound)
                    throw new Exception();           //nhảy xuống chỗ chửi nếu nhập ngoài biên            
                return n;
            } catch (Exception e) {
                System.out.println(errorMsg);
            }
        }
    }

    //hàm nhập vào số thực đích thực
    //- mọi sự nhập cà chớn bị chửi, ví dụ nhập chuỗi thay vì nhập số
    //- chống trôi lệnh, tức là ko để lại rác Enter hay kí tự nào đó
    //  trong buffer cho thằng sau hốt
    //- có câu thông báo động, tùy ngữ cảnh 
    public static double getADouble(String inputMsg, String errorMsg) {
        double n;
        
        while (true) {
            try {
                System.out.print(inputMsg);
                n = Double.parseDouble(sc.nextLine());
                return n;
            } catch (Exception e) {
                System.out.println(errorMsg);
            }
        }
    }
    
    //hàm nhập vào số thực đích thực trong khoảng cho trước
    //- mọi sự nhập cà chớn bị chửi, ví dụ nhập chuỗi thay vì nhập số
    //- chống trôi lệnh, tức là ko để lại rác Enter hay kí tự nào đó
    //  trong buffer cho thằng sau hốt 
    //- ép nhập số thực trong 1 range/khoảng cho trước
    //- có câu thông báo động, tùy ngữ cảnh 
    public static double getADouble(double lowerBound, double upperBound, String inputMsg, String errorMsg) {
        double n, tmp;
        
        //nếu đầu vào lower > upper thì hoán đổi cho thuận chiều
        //rằng nhập số trong khoảng từ lower -> đến upper
        //rằng nhập số trong khoảng từ bé -> đến lớn
        if (lowerBound > upperBound) {
            tmp = lowerBound;
            lowerBound = upperBound;
            upperBound = tmp;
        }
        
        while (true) {
            try {
                System.out.print(inputMsg);
                n = Double.parseDouble(sc.nextLine());
                if (n < lowerBound || n > upperBound)
                    throw new Exception();                
                return n;
            } catch (Exception e) {
                System.out.println(errorMsg);
            }
        }
    }
        
    //hàm nhập vào một chuỗi kí tự tuân theo một định dạng cho trước
    //chuỗi định dạng dùng kĩ thuật Regular Expression - biểu thức thường quy
    //dùng kĩ thuật này không phải if/else cho mọi tình huống người dùng đưa dữ liệu vào
    //hàm trả về chuỗi kí tự đã đổi sang chữ hoa
    //cách dùng: xem hàm main() ở ngay dưới cùng của tập tin này
    public static String getStringByPattern(String inputMsg, String errorMsg, String format) {
        String stdString;
        boolean match;
        
        while (true) {
            System.out.print(inputMsg);
            stdString = sc.nextLine().trim().toUpperCase();
            match = stdString.matches(format);
            if (stdString.length() == 0 || stdString.isEmpty() || match == false)
                System.out.println(errorMsg);
            else
                return stdString;            
        }
    }
    
    //hàm nhập vào một chuỗi kí tự tự do, khác rỗng, cắt khoảng trắng dư ở đầu và cuối chuỗi
    //hàm trả về theo đúng kí tự hoa thường như lúc nhập vào
    public static String getStringByFree(String inputMsg, String errorMsg) {
        String str;  
        
        while (true) {
            System.out.print(inputMsg);
            str = sc.nextLine().trim();            
            if (str.length() == 0 || str.isEmpty())
                System.out.println(errorMsg);
            else 
                return str;
        }
    }
    
    //hàm main() để test thử hàm nhập chuỗi kí tự tuân theo định dạng cho trước
    //Ví dụ: cần nhập một mã số sinh viên có chữ SE đầu tiên và 6 con số đi kèm phía sau
    //Đúng: SE123456, SE226789, se123456
    //Sai : SE1, AHIHI, SE12345A 
    //Nhấn Shift-F6 để chạy thử
    public static void main(String[] args) {
        String id = getStringByPattern("Input ID(SEXXXXXX): ", "Your input must be under "
                + "the format of SEXXXXXX, X stands for a digit",
                "^[S|s][E|e]\\d{6}$");
        System.out.println("Your ID: " + id);
    }
}