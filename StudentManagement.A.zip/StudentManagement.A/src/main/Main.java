package main;

import data.Cabinet;
import ui.Menu;

/**
 *
 * @author giao-lang | fb/giao.lang.bis version 20.1106
 */

//class chính, mọi thứ bắt đầu từ đây, app chạy từ đây
//CPU nhào vào hàm main() đầu tiên để chạy các lệnh theo thứ tự từ trên xuống dưới
//và xà quần trong vòng lặp cho đến khi gặp điều kiện thoát - người dùng nhấn số 7 khi được mời món
public class Main {

    public static void main(String[] args) {

        Menu mainMenu = new Menu("Happiness-Student Management System");
        mainMenu.addNewOption("1. Add a new student");
        mainMenu.addNewOption("2. Search a student by id");
        mainMenu.addNewOption("3. Update a student by id");
        mainMenu.addNewOption("4. Remove a student by id");
        mainMenu.addNewOption("5. Print the student list ascending by id");
        mainMenu.addNewOption("6. Print the student list descending by gpa");
        mainMenu.addNewOption("7. Quit");

        Cabinet folder = new Cabinet();  //mua cái tủ, đựng hồ sơ SV        
                                         //tủ có thể thêm/xóa/sửa/tìm/sort các hồ sơ mà nó chứa bên trong
        int choice;  //người dùng chọn tính năng, món mà họ muốn thao tác
        
        do {
            mainMenu.printMenu();
            choice = mainMenu.getChoice();
            switch (choice) {
                case 1:
                    System.out.println("\nYou are preparing to "
                            + "input a new student");
                    folder.addANewStudent();
                    break;               
                case 2:
                    System.out.println("\nYou are required to input "
                            + "a student id to search");
                    folder.searchAStudentById();
                    break;
                case 3:
                    System.out.println("\nYou are required to input "
                            + "a student id to update");
                    folder.updateAStudent();
                    break;
                case 4:
                    System.out.println("\nYou are required to input "
                            + "a student id to remove");
                    folder.removeAStudent();
                    break;
                case 5:
                    System.out.println("\nYou are preparing to "
                            + "print the student list ascending by id");
                    folder.printStudentListAscendingByID();
                    break;
                case 6:
                    System.out.println("\nYou are preparing to "
                            + "print the student list descending by gpa");
                    folder.printStudentListDescendingByGpa();
                    break;
                case 7:
                    System.out.println("\nBye bye, see you next time!");
                    break;
            }
        } while (choice != 7);
    }
}
